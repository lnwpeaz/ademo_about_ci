export default function useAuth() {
  // Example of a custom hook for authentication
}
